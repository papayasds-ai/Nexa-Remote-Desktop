﻿window.NEXA_DEFAULT_SERVER = "wss://nexadesk-signaling.papayasds.workers.dev"; window.NEXA_VERSION = "1.0.90";
